/* Javascript for SWPWRXBlock.
 * TODO:  Enforce assignment due date for not starting another attempt.
 *        Disble Hint and ShowMe buttons if options are set.
 */
function SWPWRXStudentFAKE(runtime, element) {

    console.info("SWPWRXStudent start");
    console.info("SWPWRXStudent element",element);

    console.info("SWPWRXStudent end");
}